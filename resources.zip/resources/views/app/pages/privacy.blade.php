@extends('app.index')

@section('content')
<div class="app white messagebox">
  
    <div class="row justify-content-center">
        <div class="col-12 col-lg-4">
            <h3 class="text-center text-[24px] font-[900] text-[#242424] mb-3">إتمام القفل</h3>
            <p class="text-center">هنا يمكنك إتمام إعداد القفل أو عرض التفاصيل.</p>
        </div>
    </div>
</div>
@endsection