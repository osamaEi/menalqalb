
<div id="rootElement" lang="en_US">
    <img src="{{ asset('app/img/curve2.png')}}" class="z-50 w-[106px] absolute" alt="">

<a href="{{ route('app.home')}}" class="z-[9999999999999] !p-2 !absolute left-0 !mt-2 icondoor">
<i class="fas fa-arrow-alt-circle-left text-white text-[19px] pl-3 w-[65px]"></i>
</a>